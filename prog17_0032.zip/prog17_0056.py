# PROGRAM - 17
# Bar Plot (Categorical vs Numerical)

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read CSV
df4 = pd.read_csv("C:/Users/HP/Desktop/PYTHON/exp_lvl.csv")

# -------------------------------
# Matplotlib Bar Plot
# -------------------------------
plt.figure()
plt.bar(df4['experience_level'], df4['salary_in_usd'],
        edgecolor='black')

plt.title("Salary by Experience Level (Matplotlib)")
plt.xlabel("Experience Level")
plt.ylabel("Salary in USD")
plt.show()

# -------------------------------
# Seaborn Bar Plot
# -------------------------------
plt.figure()
sns.barplot(x='experience_level', y='salary_in_usd', data=df4)

plt.title("Salary by Experience Level (Seaborn)")
plt.show()
